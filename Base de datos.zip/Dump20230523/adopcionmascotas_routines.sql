-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: adopcionmascotas
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vista_perros_disponibles`
--

DROP TABLE IF EXISTS `vista_perros_disponibles`;
/*!50001 DROP VIEW IF EXISTS `vista_perros_disponibles`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_perros_disponibles` AS SELECT 
 1 AS `TIPMASC_ID`,
 1 AS `TIPMASC_Nombre`,
 1 AS `TIPRAZA_ID`,
 1 AS `FKTIPMASC_ID`,
 1 AS `TIPRAZA_Nombre`,
 1 AS `FKTIPRAZA_ID`,
 1 AS `MASC_Estado`,
 1 AS `Total_mascotas_disponibles`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista_perros_disponibles`
--

/*!50001 DROP VIEW IF EXISTS `vista_perros_disponibles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_perros_disponibles` AS select `tipomascota`.`TIPMASC_ID` AS `TIPMASC_ID`,`tipomascota`.`TIPMASC_Nombre` AS `TIPMASC_Nombre`,`tiporaza`.`TIPRAZA_ID` AS `TIPRAZA_ID`,`tiporaza`.`FKTIPMASC_ID` AS `FKTIPMASC_ID`,`tiporaza`.`TIPRAZA_Nombre` AS `TIPRAZA_Nombre`,`mascota`.`FKTIPRAZA_ID` AS `FKTIPRAZA_ID`,`mascota`.`MASC_Estado` AS `MASC_Estado`,count(`mascota`.`MASC_ID`) AS `Total_mascotas_disponibles` from ((`mascota` join `tiporaza` on((`mascota`.`FKTIPRAZA_ID` = `tiporaza`.`TIPRAZA_ID`))) join `tipomascota` on((`tiporaza`.`FKTIPMASC_ID` = `tipomascota`.`TIPMASC_ID`))) where ((`tipomascota`.`TIPMASC_Nombre` = 'Perro') and (`tiporaza`.`TIPRAZA_Nombre` = 'pequeño') and (`mascota`.`MASC_Estado` = true)) group by `mascota`.`MASC_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'adopcionmascotas'
--

--
-- Dumping routines for database 'adopcionmascotas'
--
/*!50003 DROP PROCEDURE IF EXISTS `insertarFormulario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertarFormulario`(
in contacto int,
in motivoAdopcion varchar(42),
in cantidadPersonas int,
in casa varchar(2),
in alergiaCasa varchar(2),
in ubicacion varchar(42),
in enfermedades varchar(2),
in fkpersona int,
in fkmascota int,
in fktipovivienda int,
in fkpublicacion int)
begin
insert into formulario (FOR_Contacto, FOR_MotivoAdopcion, FOR_CantidadPersonasVivienda, 
FOR_CasaSegura, FOR_AlergiaEnCasa, FOR_UbicacionCasa, FOR_EnfermedadesRespiratoriasEnCasa, FKPER_Llena, FKMASC_ID, 
FKTIPVIVI_ID, FKPUBLI_ID)
values (contacto, motivoAdopcion, cantidadPersonas, casa, alergiaCasa, ubicacion, enfermedades, fkpersona, fkmascota, fktipovivienda, fkpublicacion);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertarPublicacionMascota` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertarPublicacionMascota`(
 in titulo varchar(42), 
 in descripcion varchar(100), 
 in persona int, 
 in tipoPubli int,
 in nombreMasc varchar(42),
 in edadMasc int,
 in descripcionMasc varchar(42),
 in generoMascota int,
 in caracteristicaMascota int,
 in razaMascota int,
 in fechaCirugia date,
 in tipoCirugia int,
 in fechaVacuna date,
 in fkvacuna int,
 in tratamientoAler varchar(42),
 in fechaInicioTratamiento date,
 in fechaFinTratamiento date,
 in fkAlergiaTratamiento int,
 in fkTipoTratamiento int)
begin
 insert into publicacion (PUBLI_Titulo, PUBLI_Descripcion, FKPER_RealizaPublicacion, FKTIPUBLI_ID)
 values (titulo, descripcion, persona, tipoPubli);
 insert into mascota (MASC_Nombre, MASC_Edad, MASC_Descripcion, FKGENMASC_ID, FKCARAC_ID, FKTIPRAZA_ID)
 values (nombreMasc, edadMasc, descripcionMasc, generoMascota, caracteristicaMascota, razaMascota);
 insert into cirugia (CIRU_FechaCirugia, FKTIPCIRU_ID)
 values (fechaCirugia, tipoCirugia);
 insert into masctienevac (MASCTIENVAC_FechaAplicacion, FKVAC_ID)
 values (fechaVacuna, fkvacuna);
 insert into masctienealer (MASCTIENALER_Tratamiento, MASCTIENALER_FechaInicioTratamiento, MASCTIENALER_FechaFinTratamiento, FKALER_ID, FKTIPTRAT_ID)
 values (tratamientoAler, fechaInicioTratamiento, fechaFinTratamiento, fkAlergiaTratamiento, fkTipoTratamiento);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `login`(
in correo varchar(42),
in contrasenia varchar(42)
)
begin
select PER_ID, FKROL_ID, PER_Correo, PER_Contrasenia
from persona
where PER_Correo = correo and PER_Contrasenia = contrasenia;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mascota_por_fecha` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `mascota_por_fecha`()
BEGIN
    SELECT 
        perregistramasc.PERREGISMASC_ID,
        perregistramasc.PERREGISMASC_FechaRegistro,
        perregistramasc.FKMASC_ID,
        COUNT(mascota.MASC_ID)
    FROM 
        perregistramasc
    INNER JOIN  
        mascota
        ON perregistramasc.FKMASC_ID = mascota.MASC_ID
    WHERE 
         perregistramasc.PERREGISMASC_FechaRegistro = '2023-04-10'
    GROUP BY mascota.MASC_ID, perregistramasc.PERREGISMASC_ID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `menu dinamico` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `menu dinamico`(in id_ingresado integer)
BEGIN
    SELECT 
       VistasRolPermisos.nombre_VistasRolPermisos,
       VistasRolPermisos.descripcion_VistasRolPermisos,
       VistasRolPermisos.controlador_VistasRolPermisos
       
    FROM 
        VistasRolPermisos
    INNER JOIN  
       permisos
        ON  VistasRolPermisos.fk_permiso=permisos.id_permisos
        inner join 
        PermisosRol
        on  PermisosRol.FK_Permisos=permisos.id_permisos
        inner join 
        rol 
        on permisosRol.FK_rol= rol.ROL_ID
        inner join
        persona
        on
        persona.FKROL_ID=rol.ROL_ID
    WHERE 
    persona.PER_ID=id_ingresado
    order by  VistasRolPermisos.id_VistasRolPermisos asc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `menudinamico` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `menudinamico`(in id_ingresado integer)
BEGIN
    select nombre_VistasRolPermisos, 
Controlador_VistasRolPermisos,
Accion_VistasRolPermisos
from vistasrolpermisos
inner join permisos 
on fk_permiso = id_permisos 
inner join permisosrol
on FK_Permisos = id_permisos
inner join rol
on FK_rol = ROL_ID
inner join persona
on FKROL_ID = ROL_ID and PER_ID =id_ingresado 
   where permisosrol.estado_permisos = true
    ORDER BY
        VistasRolPermisos.id_VistasRolPermisos ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mostrarDatosUsuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `mostrarDatosUsuario`(in correo varchar(45))
begin
select PER_NombreUno, 
ifnull(PER_NombreDos, 'Sin nombre') as 'Nombre Dos',
PER_ApellidoUno,
ifnull(PER_ApellidoDos, 'Sin apellido') as 'Apellido Dos',
PER_Correo,
PER_DireccionVivienda,
PER_NumeroDocumento,
TIPDOC_Nombre,
PAIS_Nombre,
DEP_Nombre,
MUN_Nombre,
BAR_Nombre
from persona
inner join tipodocumento
on FKTIPDOC_ID = TIPDOC_ID
inner join barrio
on FKBAR_ID = BAR_ID 
inner join municipio
on FKMUN_ID = MUN_ID
inner join departamento
on FKDEP_ID = DEP_ID
inner join pais 
on FKPAIS_ID = PAIS_ID
Where PER_Correo = correo;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-23 13:16:42
