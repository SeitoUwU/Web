-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: adopcionmascotas
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vistasrolpermisos`
--

DROP TABLE IF EXISTS `vistasrolpermisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vistasrolpermisos` (
  `id_VistasRolPermisos` int NOT NULL,
  `nombre_VistasRolPermisos` varchar(50) NOT NULL,
  `Descripcion_VistasRolPermisos` varchar(50) NOT NULL,
  `Controlador_VistasRolPermisos` varchar(100) NOT NULL,
  `Accion_VistasRolPermisos` varchar(100) NOT NULL,
  `fk_permiso` int DEFAULT NULL,
  PRIMARY KEY (`id_VistasRolPermisos`),
  KEY `fk_permiso_idx` (`fk_permiso`),
  CONSTRAINT `fk_permiso` FOREIGN KEY (`fk_permiso`) REFERENCES `permisos` (`id_permisos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vistasrolpermisos`
--

LOCK TABLES `vistasrolpermisos` WRITE;
/*!40000 ALTER TABLE `vistasrolpermisos` DISABLE KEYS */;
INSERT INTO `vistasrolpermisos` VALUES (1,'Eliminar publicacion ','Eliminar publicacion ','ReportesPublicacion ','AdminReportes',7),(2,'Reportes ','Reportes del sistema  ','Reportes','InicioReportes',6),(3,' Actualizar barrio','Barrio agregar','Barrio','AdminActualizaBarrio',2),(4,'Eliminar Barrio','Barrio eliminar ','Barrio','AdminEliminaBarrio',3),(5,'Agregar  Barrio','Barrio actualizar ','Barrio','AdminAgregaBarrio',1),(6,'caracteristicas Agregar','caracteristicas agregar','Caracteristicas',' AdminAgregaCaracteristica',2),(7,'caracteristicas Eliminar','caracteristicas eliminar ','Caracteristicas','AdminEliminaCaracteristicas',3),(8,'Inicio','Inicio','Usuario','InicioUsuario',8),(9,'Agregar  Departamento ','Agregar departamento ','Departamento','AdminAgregaDepartamento',1),(10,'Actulizar Departamento','Actualizar departamento','Departamento','AdminActualizaDepartamento',2),(11,'Eliminar Departamento','Eliminar Departamentos','Departamento ','AdminEliminaDepartamento',9),(12,'Caracteristicas Actualizar','Actualizar caracteristicas','Caracteristicas','AdminActualizaCaracteristicas',2),(13,'Agregar motivo reporte','reporte motivo','MotivoReportes','AdminAgregaMotivo',1),(14,'Eliminar  motivo reporte','Eliminar motivo reporte','MotivoReportes','AdminEliminaMotivo',3);
/*!40000 ALTER TABLE `vistasrolpermisos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-23 13:16:39
